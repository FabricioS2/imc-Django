function calcularIMC() {
    // Obtém os valores do formulário
    const peso = parseFloat(document.getElementById('peso').value);
    const altura = parseFloat(document.getElementById('altura').value);

    // Valida os valores
    if (!peso || !altura || altura <= 0) {
      alert('Por favor, insira valores válidos para peso e altura.');
      return;
    }

    // Calcula o IMC
    const imc = peso / (altura * altura);
    document.getElementById('imcValor').textContent = imc.toFixed(2);

    // Interpretação do IMC
    let interpretacao;
    if (imc < 18.5) {
      interpretacao = "Você está abaixo do peso ideal.";
    } else if (imc >= 18.5 && imc < 24.9) {
      interpretacao = "Seu peso está dentro da faixa normal.";
    } else if (imc >= 25 && imc < 29.9) {
      interpretacao = "Você está com sobrepeso.";
    } else {
      interpretacao = "Você está na faixa de obesidade.";
    }

    document.getElementById('interpretacao').textContent = interpretacao;
    document.getElementById('resultado').style.display = 'block';
  }